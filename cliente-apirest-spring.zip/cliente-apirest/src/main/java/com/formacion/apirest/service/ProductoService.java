package com.formacion.apirest.service;

import java.util.List;

import com.formacion.apirest.entity.Producto;

public interface ProductoService {
	
	//Mostrar todos los productos
	public List<Producto> mostrarProductos();
	
	//Mostrar producto por id
	public Producto buscarProducto(long id);
	
	//Crear nuevo producto
	public Producto guardarProducto(Producto producto);
	
	//Borrar un producto
	public Producto borrarProducto(long id);

}
